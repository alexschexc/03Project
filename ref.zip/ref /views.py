from django.shortcuts import render
from .forms import CheckBoxForm
from django.db.models import Q
from django.urls import reverse
from datetime import datetime, timedelta
from django.contrib import messages
from library.models import Authors, Book, Book_Authors, Borrower, Book_Loans, Fines

# Create your views here.
def book_search_checkout(request):
    query = request.GET.get('query', '')  # Retrieve user's search query from the URL parameter
    query = query.lower()  # Make the search case insensitive

    results = []

    if request.method == 'GET':
        if query:
            # Perform the search query using Django's Q objects for OR conditions
            search_results = Book.objects.filter(
                Q(isbn__icontains=query) |  # Search ISBN
                Q(title__icontains=query) |  # Search title
                Q(authors__name__icontains=query)  # Search authors
            ).distinct()  # Use distinct() to eliminate duplicate results

            # Check book availability
            for book in search_results:
                book.is_available = not Book_Loans.objects.filter(isbn=book.isbn, date_in__isnull=True).exists()
                results.append(book)
        return render(request, 'search_checkout.html', {'results': results})

    if request.method == 'POST':
            form = CheckBoxForm(request.POST)
    if form.is_valid():
        card_no = request.POST.get('card_no', '')
        print(card_no)
        try:
            borrower = Borrower.objects.get(card_id=card_no)
            today = datetime.now().date()
            ddate = today + timedelta(days=14)
            selected_isbns = request.POST.getlist('selected_books')
            selected_books = Book.objects.filter(isbn__in=selected_isbns)
            results = selected_books
            active_loans_count = Book_Loans.objects.filter(refer_card_id=card_no, date_in__isnull=True).count()
    
            for book in results:
                if active_loans_count < 3:
                    book.is_available = not Book_Loans.objects.filter(isbn=book.isbn, date_in__isnull=True).exists()
                    loan = Book_Loans(
                        refer_card_id=borrower,
                        isbn=book,
                        date_out=today,
                        due_date=ddate
                    )
                    loan.save()
                    active_loans_count += 1
                if active_loans_count >= 3:
                    exceeded_limit = True
                    return render(request, 'search_checkout.html', {'exceeded_limit': exceeded_limit})
            success = True
            return render(request, 'search_checkout.html', {'success': success})
        except Borrower.DoesNotExist:
            borrower_dne = True
            return render(request, 'search_checkout.html', {'borrower_dne': borrower_dne})

def checkin(request):
    results = []
    return render(request, 'checkin.html', {'results': results})

def borrower(request):
    results = []
    return render(request, 'borrower.html', {'results': results})

def fines(request):
    results = []
    return render(request, 'fines.html', {'results': results})
