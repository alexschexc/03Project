from django.urls import path
from library import views

urlpatterns = [
    path("", views.book_search_checkout, name="search_checkout"),
    path('checkin/', views.checkin, name='checkin'),
    path('borrower/', views.borrower, name='borrower'),
    path('fines/', views.fines, name='fines'),
]